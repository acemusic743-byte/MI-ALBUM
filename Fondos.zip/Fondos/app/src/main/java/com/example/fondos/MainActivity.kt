package com.example.fondos

import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {

    private val ORIG = "ORIG"
    private lateinit var dir: File
    private lateinit var prefs: SharedPreferences
    private val files = mutableListOf<File>()
    private val undo = ArrayList<String>()
    private val redo = ArrayList<String>()
    private var current = ORIG
    private var flags = 3 // 1 = inicio, 2 = bloqueo, 3 = ambas
    private lateinit var adapter: BaseAdapter
    private lateinit var btnUndo: Button
    private lateinit var btnRedo: Button
    private lateinit var title: TextView
    private var thumbSize = 300

    // álbumes y estilo
    private val albums = LinkedHashMap<String, MutableList<String>>()
    private var currentAlbum: String? = null
    private var mono = ""
    private var pdfPalette = 0

    private val pick = registerForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris -> addPhotos(uris) }

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri -> uri?.let { exportZip(it) } }

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { importZip(it) } }

    private val pdfLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> uri?.let { exportPdf(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dir = File(filesDir, "photos").also { it.mkdirs() }
        prefs = getSharedPreferences("estado", MODE_PRIVATE)
        loadState()
        thumbSize = resources.displayMetrics.widthPixels / 3

        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false
            setOnClickListener { a() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        fun row(vararg b: Button) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            b.forEach { addView(it) }
        }

        btnUndo = btn("↶ Deshacer") { move(undo, redo) }
        btnRedo = btn("Rehacer ↷") { move(redo, undo) }
        title = TextView(this).apply { textSize = 16f; setPadding(8, 16, 8, 16) }

        val grid = GridView(this).apply {
            numColumns = 3
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        adapter = object : BaseAdapter() {
            override fun getCount() = files.size
            override fun getItem(p: Int) = files[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val iv = (v as? ImageView) ?: ImageView(this@MainActivity).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    layoutParams = AbsListView.LayoutParams(thumbSize, thumbSize)
                }
                iv.setImageBitmap(Decor.decode(files[p], thumbSize))
                return iv
            }
        }
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, p, _ -> photoMenu(files[p]) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (12 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad * 3, pad, pad)
            addView(row(
                btn("Añadir") { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                btn("Álbumes") { albumsDialog() },
                btn("Más") { moreMenu() }
            ))
            addView(row(btnUndo, btnRedo))
            addView(title)
            addView(grid)
        }
        setContentView(root)
        refresh()
    }

    // ---------- fotos ----------
    private fun refresh() {
        val all = dir.listFiles()?.sortedBy { it.lastModified() } ?: emptyList()
        files.clear()
        val a = currentAlbum
        val list = if (a != null) albums[a] else null
        if (list == null) { currentAlbum = null; files.addAll(all) }
        else files.addAll(list.mapNotNull { n -> all.find { it.name == n } })
        title.text = (currentAlbum ?: "Todas las fotos") + " · " + files.size
        adapter.notifyDataSetChanged()
        btnUndo.isEnabled = undo.isNotEmpty()
        btnRedo.isEnabled = redo.isNotEmpty()
    }

    private fun addPhotos(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val target = currentAlbum
        thread {
            val names = mutableListOf<String>()
            uris.forEach { u ->
                try {
                    contentResolver.openInputStream(u)?.use { i ->
                        val f = File(dir, UUID.randomUUID().toString() + ".jpg")
                        f.outputStream().use { i.copyTo(it) }
                        names.add(f.name)
                    }
                } catch (_: Exception) {}
            }
            runOnUiThread {
                if (target != null) albums[target]?.addAll(names)
                saveAlbums(); refresh()
            }
        }
    }

    private fun photoMenu(f: File) {
        val labels = mutableListOf("Usar como fondo", "Decorar estilo old money", "Añadir a un álbum")
        if (currentAlbum != null) labels.add("Quitar de este álbum")
        labels.add("Eliminar")
        AlertDialog.Builder(this).setItems(labels.toTypedArray()) { _, which ->
            when (labels[which]) {
                "Usar como fondo" -> applyWallpaper(f)
                "Decorar estilo old money" -> decorateDialog(f)
                "Añadir a un álbum" -> addToAlbumDialog(f)
                "Quitar de este álbum" -> { albums[currentAlbum]?.remove(f.name); saveAlbums(); refresh() }
                else -> {
                    f.delete(); albums.values.forEach { it.remove(f.name) }
                    saveAlbums(); refresh()
                }
            }
        }.show()
    }

    // ---------- álbumes ----------
    private fun clean(s: String) = s.replace(Regex("[\\t\\n|]"), " ").trim().take(40)

    private fun askText(t: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(this).apply { setText(initial); setSingleLine() }
        AlertDialog.Builder(this).setTitle(t).setView(et)
            .setPositiveButton("Aceptar") { _, _ -> ok(et.text.toString().trim()) }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun albumsDialog() {
        val names = listOf("Todas las fotos") + albums.keys + "＋ Nuevo álbum"
        AlertDialog.Builder(this).setTitle("Álbumes").setItems(names.toTypedArray()) { _, i ->
            if (i == names.lastIndex) {
                askText("Nombre del álbum", "") { n ->
                    val c = clean(n)
                    if (c.isNotEmpty()) { albums.getOrPut(c) { mutableListOf() }; currentAlbum = c; saveAlbums(); refresh() }
                }
            } else {
                currentAlbum = if (i == 0) null else names[i]
                refresh()
            }
        }.show()
    }

    private fun addToAlbumDialog(f: File) {
        val names = albums.keys.toList() + "＋ Nuevo álbum"
        AlertDialog.Builder(this).setTitle("Añadir a…").setItems(names.toTypedArray()) { _, i ->
            if (i == names.lastIndex) {
                askText("Nombre del álbum", "") { n ->
                    val c = clean(n)
                    if (c.isNotEmpty()) {
                        albums.getOrPut(c) { mutableListOf() }.add(f.name); saveAlbums(); refresh()
                    }
                }
            } else {
                val l = albums[names[i]]!!
                if (f.name !in l) l.add(f.name)
                saveAlbums(); refresh(); toast("Añadida a ${names[i]}")
            }
        }.show()
    }

    /** Crea un álbum por cada mes según la fecha de la foto (EXIF o fecha del archivo). */
    private fun generateByDate() {
        thread {
            val fmt = SimpleDateFormat("MMMM yyyy", Locale("es"))
            val exifFmt = SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
            val groups = LinkedHashMap<String, MutableList<String>>()
            dir.listFiles()?.sortedBy { it.lastModified() }?.forEach { f ->
                val d = try {
                    exifFmt.parse(ExifInterface(f.path).getAttribute(ExifInterface.TAG_DATETIME)!!)
                } catch (_: Exception) { null } ?: Date(f.lastModified())
                val n = fmt.format(d).replaceFirstChar { it.uppercase() }
                groups.getOrPut(n) { mutableListOf() }.add(f.name)
            }
            runOnUiThread {
                groups.forEach { (n, l) -> albums[n] = l }
                saveAlbums(); refresh()
                toast(if (groups.isEmpty()) "No hay fotos" else "${groups.size} álbumes generados")
            }
        }
    }

    private fun moreMenu() {
        val labels = arrayOf(
            "Generar álbumes por fecha",
            "Exportar álbum en PDF (old money)",
            "Monograma (iniciales)",
            "Eliminar álbum actual",
            "Exportar ZIP",
            "Importar ZIP",
            "Posdata"
        )
        AlertDialog.Builder(this).setItems(labels) { _, w ->
            when (w) {
                0 -> generateByDate()
                1 -> if (files.isEmpty()) toast("No hay fotos que exportar") else {
                    AlertDialog.Builder(this).setTitle("Estilo del álbum")
                        .setItems(Decor.palettes.map { it.name }.toTypedArray()) { _, i ->
                            pdfPalette = i
                            pdfLauncher.launch((currentAlbum ?: "album") + ".pdf")
                        }.show()
                }
                2 -> askText("Monograma (hasta 3 letras)", mono) {
                    mono = it.filter { c -> c.isLetter() }.take(3)
                    prefs.edit().putString("mono", mono).apply()
                    toast(if (mono.isEmpty()) "Monograma quitado" else "Monograma: ${mono.uppercase()}")
                }
                3 -> {
                    val a = currentAlbum
                    if (a == null) toast("Abre primero un álbum")
                    else AlertDialog.Builder(this)
                        .setMessage("¿Eliminar el álbum \"$a\"? Las fotos no se borran.")
                        .setPositiveButton("Eliminar") { _, _ ->
                            albums.remove(a); currentAlbum = null; saveAlbums(); refresh()
                        }.setNegativeButton("Cancelar", null).show()
                }
                4 -> exportLauncher.launch("fondos.zip")
                5 -> importLauncher.launch(arrayOf("application/zip"))
                else -> posdata()
            }
        }.show()
    }

    // ---------- decoración old money ----------
    private fun decorateDialog(f: File) {
        AlertDialog.Builder(this).setTitle("Estilo old money")
            .setItems(Decor.styleNames.toTypedArray()) { _, style ->
                val dm = resources.displayMetrics
                val target = currentAlbum
                val m = mono
                thread {
                    val src = Decor.decode(f, 2000)
                    if (src == null) { runOnUiThread { toast("No se pudo leer la foto") }; return@thread }
                    val out = Decor.decorate(src, style, dm.widthPixels, dm.heightPixels, m)
                    val nf = File(dir, UUID.randomUUID().toString() + ".jpg")
                    nf.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                    src.recycle(); out.recycle()
                    runOnUiThread {
                        if (target != null) albums[target]?.add(nf.name)
                        saveAlbums(); refresh()
                        AlertDialog.Builder(this).setMessage("Decoración lista. ¿Usarla como fondo ahora?")
                            .setPositiveButton("Sí") { _, _ -> applyWallpaper(nf) }
                            .setNegativeButton("Después", null).show()
                    }
                }
            }.show()
    }

    // ---------- PDF del álbum ----------
    private fun exportPdf(uri: Uri) {
        val list = files.toList()
        val name = currentAlbum ?: "Mis fotos"
        val pal = Decor.palettes[pdfPalette]
        val m = mono
        thread {
            val ok = try {
                val pdf = PdfDocument()
                val w = 595; val h = 842
                var page = pdf.startPage(PdfDocument.PageInfo.Builder(w, h, 1).create())
                Decor.drawCover(page.canvas, w.toFloat(), h.toFloat(), name, m, pal)
                pdf.finishPage(page)
                list.forEachIndexed { i, f ->
                    val bmp = Decor.decode(f, 1400)
                    page = pdf.startPage(PdfDocument.PageInfo.Builder(w, h, i + 2).create())
                    Decor.drawPage(page.canvas, w.toFloat(), h.toFloat(), bmp, i + 1, pal, m)
                    pdf.finishPage(page)
                    bmp?.recycle()
                }
                contentResolver.openOutputStream(uri)!!.use { pdf.writeTo(it) }
                pdf.close()
                true
            } catch (e: Exception) { false }
            runOnUiThread { toast(if (ok) "Álbum PDF guardado" else "Error al crear el PDF") }
        }
    }

    // ---------- posdata ----------
    private fun posdata() {
        val d = resources.displayMetrics.density
        val ink = 0xFF6B5532.toInt()
        val gold = 0xFFB8975A.toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFFF3EAD3.toInt())
            val p = (28 * d).toInt()
            setPadding(p, p, p, p)
        }
        fun line(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            gravity = android.view.Gravity.CENTER
            typeface = android.graphics.Typeface.create(
                android.graphics.Typeface.SERIF,
                if (bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.ITALIC)
            setPadding(0, (6 * d).toInt(), 0, (6 * d).toInt())
        }
        box.addView(line("P.D.", 28f, gold, true))
        box.addView(line("— ◆ —", 16f, gold))
        box.addView(line("Regalo de tu hijastro", 18f, ink))
        box.addView(line("Santiago Alexander\nAcevedo Paredes", 24f, ink, true))
        AlertDialog.Builder(this).setView(box).setPositiveButton("Cerrar", null).show()
    }

    // ---------- fondo de pantalla ----------
    private fun applyWallpaper(f: File) {
        val go = { fl: Int ->
            flags = fl
            thread {
                saveOriginalOnce()
                val ok = setWp(f)
                runOnUiThread {
                    if (ok) {
                        undo.add(current); redo.clear(); current = f.name; saveState()
                        toast("Fondo cambiado")
                    } else toast("No se pudo cambiar el fondo")
                    refresh()
                }
            }
        }
        if (Build.VERSION.SDK_INT < 24) go(1)
        else AlertDialog.Builder(this)
            .setItems(arrayOf("Pantalla de inicio", "Pantalla de bloqueo", "Ambas")) { _, w -> go(w + 1) }
            .show()
    }

    private fun setWp(f: File): Boolean = try {
        val wm = WallpaperManager.getInstance(this)
        f.inputStream().use { s ->
            if (Build.VERSION.SDK_INT >= 24) wm.setStream(s, null, true, flags) else wm.setStream(s)
        }
        true
    } catch (e: Exception) { false }

    private fun saveOriginalOnce() {
        val orig = File(filesDir, "original.png")
        if (orig.exists()) return
        try {
            val d = WallpaperManager.getInstance(this).drawable ?: return
            val bmp = Bitmap.createBitmap(
                d.intrinsicWidth.coerceAtLeast(1), d.intrinsicHeight.coerceAtLeast(1),
                Bitmap.Config.ARGB_8888
            )
            d.setBounds(0, 0, bmp.width, bmp.height)
            d.draw(Canvas(bmp))
            orig.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) {}
    }

    // ---------- deshacer / rehacer ----------
    private fun move(from: ArrayList<String>, to: ArrayList<String>) {
        if (from.isEmpty()) return
        val target = from.last()
        val f = if (target == ORIG) File(filesDir, "original.png") else File(dir, target)
        if (!f.exists()) {
            from.removeAt(from.lastIndex); saveState(); refresh()
            toast("Esa imagen ya no está disponible"); return
        }
        thread {
            val ok = setWp(f)
            runOnUiThread {
                if (ok) {
                    from.removeAt(from.lastIndex); to.add(current); current = target; saveState()
                } else toast("Error al cambiar el fondo")
                refresh()
            }
        }
    }

    // ---------- estado persistente ----------
    private fun serializeAlbums(only: Set<String>? = null) = albums.mapNotNull { (k, v) ->
        val l = if (only == null) v else v.filter { it in only }
        if (l.isEmpty() && only != null) null else "$k\t${l.joinToString("|")}"
    }.joinToString("\n")

    private fun mergeAlbums(text: String, map: (String) -> String?) {
        text.lines().forEach { line ->
            val p = line.split("\t")
            if (p.size == 2) {
                val name = clean(p[0])
                val items = p[1].split("|").filter { it.isNotEmpty() }.mapNotNull(map)
                if (name.isNotEmpty()) albums.getOrPut(name) { mutableListOf() }.addAll(items.filter { it !in albums[name].orEmpty() })
            }
        }
    }

    private fun saveAlbums() = prefs.edit().putString("albums", serializeAlbums()).apply()

    private fun saveState() {
        prefs.edit()
            .putString("undo", undo.joinToString("|"))
            .putString("redo", redo.joinToString("|"))
            .putString("current", current)
            .putInt("flags", flags)
            .apply()
    }

    private fun loadState() {
        fun list(k: String) = (prefs.getString(k, "") ?: "").split("|").filter { it.isNotEmpty() }
        undo.addAll(list("undo")); redo.addAll(list("redo"))
        current = prefs.getString("current", ORIG) ?: ORIG
        flags = prefs.getInt("flags", 3)
        mono = prefs.getString("mono", "") ?: ""
        mergeAlbums(prefs.getString("albums", "") ?: "") { it }
    }

    // ---------- archivo ZIP (fotos + álbumes) ----------
    private fun exportZip(uri: Uri) {
        val list = files.toList()
        val albumText = serializeAlbums(list.map { it.name }.toSet())
        thread {
            val ok = try {
                contentResolver.openOutputStream(uri)!!.use { o ->
                    ZipOutputStream(o).use { z ->
                        list.forEach { f ->
                            z.putNextEntry(ZipEntry(f.name))
                            f.inputStream().use { it.copyTo(z) }
                            z.closeEntry()
                        }
                        z.putNextEntry(ZipEntry("albums.txt"))
                        z.write(albumText.toByteArray(Charsets.UTF_8))
                        z.closeEntry()
                    }
                }
                true
            } catch (e: Exception) { false }
            runOnUiThread { toast(if (ok) "ZIP guardado" else "Error al exportar") }
        }
    }

    private fun importZip(uri: Uri) {
        thread {
            var n = 0
            val map = HashMap<String, String>()
            var albumText: String? = null
            try {
                ZipInputStream(contentResolver.openInputStream(uri)!!).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        if (!e.isDirectory) {
                            val base = File(e.name).name
                            if (base == "albums.txt") {
                                albumText = z.readBytes().toString(Charsets.UTF_8)
                            } else {
                                var out = File(dir, base)
                                if (out.exists() || !base.endsWith(".jpg"))
                                    out = File(dir, UUID.randomUUID().toString() + ".jpg")
                                out.outputStream().use { z.copyTo(it) }
                                val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                                android.graphics.BitmapFactory.decodeFile(out.path, o)
                                if (o.outWidth > 0) { n++; map[base] = out.name } else out.delete()
                            }
                        }
                        e = z.nextEntry
                    }
                }
            } catch (_: Exception) {}
            runOnUiThread {
                albumText?.let { t -> mergeAlbums(t) { map[it] }; saveAlbums() }
                toast("$n fotos importadas"); refresh()
            }
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
