package com.example.fondos

import android.graphics.*
import java.io.File
import kotlin.math.hypot
import kotlin.math.max

/** Paleta old money: fondo, línea dorada, passepartout, tinta. */
class Palette(val name: String, val bg: Int, val line: Int, val mat: Int, val ink: Int)

object Decor {

    val palettes = listOf(
        Palette("Crema clásico", 0xFFF3EAD3.toInt(), 0xFFB8975A.toInt(), 0xFFFBF6E9.toInt(), 0xFF6B5532.toInt()),
        Palette("Verde inglés", 0xFF1F3A2E.toInt(), 0xFFC9A961.toInt(), 0xFFEFE6CF.toInt(), 0xFFC9A961.toInt()),
        Palette("Burdeos", 0xFF4A1C24.toInt(), 0xFFC9A961.toInt(), 0xFFEFE6CF.toInt(), 0xFFC9A961.toInt()),
        Palette("Azul marino", 0xFF14213D.toInt(), 0xFFC9A961.toInt(), 0xFFEFE6CF.toInt(), 0xFFC9A961.toInt())
    )
    /** Índice extra: sepia vintage a pantalla completa. */
    const val SEPIA = 4
    val styleNames = palettes.map { it.name } + "Sepia vintage"

    private val serif = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
    private val serifBold = Typeface.create(Typeface.SERIF, Typeface.BOLD)

    // ---------- carga de imágenes (con rotación EXIF) ----------
    fun decode(f: File, maxDim: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0) return null
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > maxDim) s *= 2
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        val deg = try {
            when (android.media.ExifInterface(f.path).getAttributeInt(
                android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
            }
        } catch (_: Exception) { 0f }
        if (deg == 0f) return bmp
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun drawCrop(c: Canvas, src: Bitmap, dst: RectF, paint: Paint) {
        val da = dst.width() / dst.height()
        val sa = src.width.toFloat() / src.height
        val r = if (sa > da) {
            val nw = (src.height * da).toInt()
            Rect((src.width - nw) / 2, 0, (src.width + nw) / 2, src.height)
        } else {
            val nh = (src.width / da).toInt()
            Rect(0, (src.height - nh) / 2, src.width, (src.height + nh) / 2)
        }
        c.drawBitmap(src, r, dst, paint)
    }

    private fun stroke(color: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; this.color = color; strokeWidth = w
    }

    // ---------- adorno y monograma ----------
    private fun ornament(c: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
        val p = stroke(color, size * 0.06f)
        c.drawLine(cx - size, cy, cx - size * 0.25f, cy, p)
        c.drawLine(cx + size * 0.25f, cy, cx + size, cy, p)
        val d = Path().apply {
            moveTo(cx, cy - size * 0.18f); lineTo(cx + size * 0.18f, cy)
            lineTo(cx, cy + size * 0.18f); lineTo(cx - size * 0.18f, cy); close()
        }
        c.drawPath(d, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
    }

    private fun monogram(c: Canvas, cx: Float, cy: Float, r: Float, text: String, p: Palette) {
        c.drawCircle(cx, cy, r, stroke(p.line, r * 0.05f))
        c.drawCircle(cx, cy, r * 0.88f, stroke(p.line, r * 0.02f))
        val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = p.ink; typeface = serifBold; textAlign = Paint.Align.CENTER
            textSize = r * (if (text.length > 2) 0.62f else 0.8f); letterSpacing = 0.1f
        }
        val fm = t.fontMetrics
        c.drawText(text, cx, cy - (fm.ascent + fm.descent) / 2, t)
    }

    // ---------- composición enmarcada (fondo de pantalla y páginas) ----------
    fun drawFramed(c: Canvas, w: Float, h: Float, photo: Bitmap?, p: Palette, mono: String, caption: String?) {
        c.drawColor(p.bg)
        c.drawRect(w * 0.04f, w * 0.04f, w * 0.96f, h - w * 0.04f, stroke(p.line, w * 0.005f))
        c.drawRect(w * 0.06f, w * 0.06f, w * 0.94f, h - w * 0.06f, stroke(p.line, w * 0.002f))

        val mat = RectF(w * 0.12f, h * 0.09f, w * 0.88f, h * 0.72f)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = p.mat }
        c.drawRect(mat, fill)
        c.drawRect(mat, stroke(p.line, w * 0.002f))
        val ph = RectF(mat).apply { inset(w * 0.04f, w * 0.04f) }
        if (photo != null) drawCrop(c, photo, ph, Paint(Paint.FILTER_BITMAP_FLAG))
        c.drawRect(ph, stroke(0x66000000, w * 0.002f))

        var y = mat.bottom + h * 0.045f
        if (!caption.isNullOrBlank()) {
            val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = p.ink; typeface = serif; textAlign = Paint.Align.CENTER; textSize = w * 0.045f
            }
            c.drawText(caption, w / 2, y + t.textSize * 0.4f, t)
            y += t.textSize * 1.4f
        }
        if (mono.isNotBlank()) monogram(c, w / 2, h - h * 0.11f, w * 0.075f, mono.uppercase(), p)
        else ornament(c, w / 2, h - h * 0.10f, w * 0.12f, p.line)
    }

    fun framedWallpaper(src: Bitmap, w: Int, h: Int, p: Palette, mono: String): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        drawFramed(Canvas(out), w.toFloat(), h.toFloat(), src, p, mono, null)
        return out
    }

    // ---------- sepia vintage con viñeta ----------
    fun sepiaWallpaper(src: Bitmap, w: Int, h: Int, mono: String): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val cm = ColorMatrix().apply { setSaturation(0f) }
        cm.postConcat(ColorMatrix(floatArrayOf(
            1.0f, 0f, 0f, 0f, 25f,
            0f, 0.88f, 0f, 0f, 10f,
            0f, 0f, 0.68f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f)))
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) }
        drawCrop(c, src, RectF(0f, 0f, w.toFloat(), h.toFloat()), paint)
        val vig = Paint().apply {
            shader = RadialGradient(w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) / 2f,
                intArrayOf(0x00000000, 0x00000000, 0xAA301800.toInt()),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), vig)
        val cream = 0xCCEFE6CF.toInt()
        c.drawRect(w * 0.04f, w * 0.04f, w * 0.96f, h - w * 0.04f, stroke(cream, w * 0.004f))
        if (mono.isNotBlank()) {
            val pal = Palette("", 0, cream, 0, cream)
            monogram(c, w / 2f, h - h * 0.08f, w * 0.06f, mono.uppercase(), pal)
        }
        return out
    }

    fun decorate(src: Bitmap, style: Int, w: Int, h: Int, mono: String): Bitmap =
        if (style == SEPIA) sepiaWallpaper(src, w, h, mono)
        else framedWallpaper(src, w, h, palettes[style], mono)

    // ---------- páginas del álbum en PDF ----------
    fun roman(n: Int): String {
        val v = intArrayOf(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
        val s = arrayOf("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")
        var x = n; val sb = StringBuilder()
        for (i in v.indices) while (x >= v[i]) { sb.append(s[i]); x -= v[i] }
        return sb.toString()
    }

    fun drawCover(c: Canvas, w: Float, h: Float, title: String, mono: String, p: Palette) {
        c.drawColor(p.bg)
        c.drawRect(w * 0.06f, w * 0.06f, w * 0.94f, h - w * 0.06f, stroke(p.line, w * 0.006f))
        c.drawRect(w * 0.09f, w * 0.09f, w * 0.91f, h - w * 0.09f, stroke(p.line, w * 0.002f))
        val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = p.line; typeface = serif; textAlign = Paint.Align.CENTER
            textSize = w * 0.04f; letterSpacing = 0.3f
        }
        c.drawText("C O L E C C I Ó N", w / 2, h * 0.30f, small)
        ornament(c, w / 2, h * 0.34f, w * 0.14f, p.line)
        val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = p.mat; typeface = serifBold; textAlign = Paint.Align.CENTER; textSize = w * 0.10f
        }
        if (p.bg == palettes[0].bg) big.color = p.ink
        // título con ajuste de ancho
        while (big.measureText(title) > w * 0.7f && big.textSize > 10f) big.textSize -= 2f
        c.drawText(title, w / 2, h * 0.47f, big)
        ornament(c, w / 2, h * 0.52f, w * 0.14f, p.line)
        if (mono.isNotBlank()) monogram(c, w / 2, h * 0.72f, w * 0.10f, mono.uppercase(), p)
    }

    fun drawPage(c: Canvas, w: Float, h: Float, photo: Bitmap?, n: Int, p: Palette, mono: String) {
        drawFramed(c, w, h, photo, p, mono, "Lámina " + roman(n))
    }
}
